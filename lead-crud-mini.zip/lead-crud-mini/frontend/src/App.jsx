import { useEffect, useState } from 'react';
import axios from 'axios';

const api = axios.create({ baseURL: 'http://localhost:5000/api' });
const emptyForm = { name: '', email: '', phone: '', company: '', status: 'New' };

export default function App() {
  const [leads, setLeads] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  async function loadLeads() {
    try {
      const response = await api.get('/leads');
      setLeads(response.data);
    } catch (error) {
      setMessage('Could not load leads. Check that the backend and MongoDB are running.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadLeads(); }, []);

  function handleChange(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setMessage('');
    try {
      if (editingId) {
        await api.put(`/leads/${editingId}`, form);
        setMessage('Lead updated.');
      } else {
        await api.post('/leads', form);
        setMessage('Lead added.');
      }
      setForm(emptyForm);
      setEditingId(null);
      await loadLeads();
    } catch (error) {
      setMessage(error.response?.data?.message || 'Could not save lead.');
    }
  }

  function editLead(lead) {
    setForm({
      name: lead.name || '', email: lead.email || '', phone: lead.phone || '',
      company: lead.company || '', status: lead.status || 'New'
    });
    setEditingId(lead._id);
    setMessage('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function deleteLead(id) {
    if (!window.confirm('Delete this lead?')) return;
    try {
      await api.delete(`/leads/${id}`);
      if (editingId === id) cancelEdit();
      setMessage('Lead deleted.');
      await loadLeads();
    } catch (error) {
      setMessage(error.response?.data?.message || 'Could not delete lead.');
    }
  }

  function cancelEdit() {
    setForm(emptyForm);
    setEditingId(null);
  }

  return (
    <main className="page">
      <header>
        <h1>Lead Manager</h1>
        <p>A simple place to add and manage leads.</p>
      </header>

      <section className="panel">
        <h2>{editingId ? 'Edit lead' : 'Add a lead'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="fields">
            <label>Name *<input name="name" value={form.name} onChange={handleChange} required /></label>
            <label>Email<input name="email" type="email" value={form.email} onChange={handleChange} /></label>
            <label>Phone<input name="phone" value={form.phone} onChange={handleChange} /></label>
            <label>Company<input name="company" value={form.company} onChange={handleChange} /></label>
            <label>Status
              <select name="status" value={form.status} onChange={handleChange}>
                <option>New</option><option>Contacted</option><option>Qualified</option><option>Lost</option>
              </select>
            </label>
          </div>
          <div className="form-actions">
            <button type="submit">{editingId ? 'Save changes' : 'Add lead'}</button>
            {editingId && <button type="button" className="secondary" onClick={cancelEdit}>Cancel</button>}
          </div>
        </form>
        {message && <p className="message">{message}</p>}
      </section>

      <section className="panel">
        <h2>Leads <span className="count">{leads.length}</span></h2>
        {loading ? <p>Loading leads...</p> : leads.length === 0 ? <p>No leads yet. Add one using the form above.</p> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>{leads.map((lead) => (
                <tr key={lead._id}>
                  <td>{lead.name}</td><td>{lead.email || '—'}</td><td>{lead.phone || '—'}</td>
                  <td>{lead.company || '—'}</td><td><span className="status">{lead.status}</span></td>
                  <td className="actions"><button className="small secondary" onClick={() => editLead(lead)}>Edit</button><button className="small danger" onClick={() => deleteLead(lead._id)}>Delete</button></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </section>
      <footer>Mini project · React, Express and MongoDB</footer>
    </main>
  );
}
