# Mini Lead CRUD

A small React + Express + MongoDB project focused only on Leads CRUD. There is no login/authentication module. Styling is intentionally minimal.

## Requirements
- Node.js 18+
- MongoDB running locally

## Run backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
Backend: http://localhost:5000

## Run frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

The backend uses `mongodb://127.0.0.1:27017/lead_crud` by default. Leads are stored in the `leads` collection. No seed command is needed; create leads from the UI.

## Lead fields
- name (required)
- email
- phone
- company
- status (`New`, `Contacted`, `Qualified`, `Lost`)

This is a deliberately small learning/demo project, not production-hardened. It has no authentication or authorization.
